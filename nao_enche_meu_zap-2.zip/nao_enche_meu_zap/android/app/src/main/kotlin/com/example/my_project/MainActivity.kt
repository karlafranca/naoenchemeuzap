package com.fkweb.naoenchemeuzap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
